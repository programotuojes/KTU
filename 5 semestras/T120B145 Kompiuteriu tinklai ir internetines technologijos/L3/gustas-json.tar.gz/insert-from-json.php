<?php
$server="localhost";
$user="stud";
$password="stud";
$dbname="stud";
$table="gustasklevinskas";

$conn = new mysqli($server, $user, $password, $dbname);
if ($conn->connect_error) die("Can't connect " . $conn->connect_error);

$json_data = file_get_contents("insert-to-db.json");
$array = json_decode($json_data, true);


foreach ($array["rows"] as $row) {
    $name = $row["vardas"];
    $epastas = $row["epastas"];
    $kam = $row["kam"];
    $date = date("Y-m-d H:i:s");
    $ip = $_SERVER["REMOTE_ADDR"];
    $zinute = $row["zinute"];

    $sql = "INSERT INTO $table (vardas, epastas, kam, data, ip, zinute)
            VALUES ('$name', '$epastas', '$kam', '$date', '$ip', '$zinute')";

    if (!$result = $conn->query($sql)) die("Can't write: " . $conn->error);
}

echo "Saved successfully"
?>
