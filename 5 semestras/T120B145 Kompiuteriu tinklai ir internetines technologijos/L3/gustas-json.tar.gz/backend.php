<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");

// // Check GET parameters
// if (isset($_GET["vardas"]) && !preg_match("^[a-zA-ZĄČĘĖĮŠŲŪŽąčęėįšųūž]+$#", $_GET["vardas"]))  {
//     $outp = array("Nekorektiški parametrai"=>"vardas:".$_GET["vardas"]);
//     http_response_code(400);
//     goto end;
// }

if (isset($_GET["kiek"]) && $_GET["kiek"] <= 0) {
    $outp = array("Nekorektiški parametrai"=>"kiek:".$_GET["kiek"]);
    http_response_code(400);
    goto end;
}

$server="localhost";
$user="stud";
$password="stud";
$dbname="stud";
$table="gustasklevinskas";

$conn = new mysqli($server, $user, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    $outp = array("Serverio klaida"=>$conn->connect_error);
    goto end;
}

$sql = "SELECT id, vardas, kam, data, zinute FROM $table";

if (isset($_GET["vardas"]))
    $sql .= " WHERE vardas = '" . $_GET["vardas"] . "'";
    
$sql .= " ORDER BY id DESC";

if (isset($_GET["kiek"]))
    $sql .= " LIMIT " . $_GET["kiek"];

if (!$result = $conn->query($sql)) {
    http_response_code(500);
    $outp = array("Serverio klaida"=>$conn->error);
    goto end;
}

if (!$result = $conn->query($sql)){
    $outp = array("Negaliu nuskaityti ". $table => $conn->error);
    http_response_code(500);
} else {
    if (mysqli_num_rows($result) == 0) {
		$outp = array("Nėra žmonių "=>$_GET["vardas"]);
		http_response_code(400);
	} else {
		$outp = $result->fetch_all(MYSQLI_ASSOC);
        http_response_code(200);
	}
}

end:
echo json_encode($outp);

?>
